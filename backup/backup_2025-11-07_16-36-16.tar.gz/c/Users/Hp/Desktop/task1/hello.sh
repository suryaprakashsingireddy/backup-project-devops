#!/bin/bash

read -p "Enter first number: " num1
read -p "Enter second number: " num2
read -p "Enter operator (+, -, *): " op

case $op in
  +) result=$((num1 + num2)) ;;
  -) result=$((num1 - num2)) ;;
  \*) result=$((num1 * num2)) ;;
  *) echo "Invalid operator"; exit 1 ;;
esac

echo "Result: $result"




count=$(find . -maxdepth 1 -type f | wc -l)
echo "Number of files in the current directory: $count"





while true
do
    read -p "Enter a name (or type 'done' to stop): " name
    
    if [ "$name" = "done" ]; then
        echo "Goodbye!"
        break
    fi
    
    echo "Hello, $name!"
done


# Temperature Converter: Celsius → Fahrenheit

read -p "Enter temperature in Celsius: " celsius

fahrenheit=$(echo "scale=2; $celsius * 9 / 5 + 32")

echo "$celsius°C = $fahrenheit°F"
